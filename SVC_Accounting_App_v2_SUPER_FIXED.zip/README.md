# SVC Accounting App v2 - Full Starter Project

This archive is configured for Codemagic builds.
