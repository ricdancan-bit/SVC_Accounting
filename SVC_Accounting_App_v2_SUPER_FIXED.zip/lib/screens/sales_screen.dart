import 'package:flutter/material.dart';
import '../products.dart';

class SalesScreen extends StatefulWidget { const SalesScreen({super.key}); @override State<SalesScreen> createState() => _SalesScreenState(); }

class _SalesScreenState extends State<SalesScreen> {
  String selectedProduct = '1 Litre Drinker';
  int qty = 1;

  @override Widget build(BuildContext context) {
    return Scaffold(appBar: AppBar(title: const Text('Add Sale'), backgroundColor: const Color(0xFF0A3D62)),
      body: Padding(padding: const EdgeInsets.all(12.0), child: Column(children: [
        DropdownButtonFormField<String>(value: selectedProduct, items: productPrices.keys.map((p)=>DropdownMenuItem(value:p, child: Text(p))).toList(), onChanged: (v){ setState(()=>selectedProduct=v!); }),
        const SizedBox(height:8),
        TextField(decoration: const InputDecoration(labelText: 'Quantity'), keyboardType: TextInputType.number, onChanged: (v){ qty=int.tryParse(v) ?? 1; }),
        const SizedBox(height:12),
        ElevatedButton(onPressed: _save, child: const Text('Save Sale'), style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF145A8D)))
      ])));
  }

  void _save() {
    final price = productPrices[selectedProduct] ?? 0;
    final total = price * qty;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Saved: \$total KES (placeholder)')));
  }
}
