import 'package:flutter/material.dart';
class ExpensesScreen extends StatefulWidget { const ExpensesScreen({super.key}); @override State<ExpensesScreen> createState() => _ExpensesScreenState(); }
class _ExpensesScreenState extends State<ExpensesScreen> {
  final _title = TextEditingController();
  final _amount = TextEditingController();
  @override Widget build(BuildContext context) {
    return Scaffold(appBar: AppBar(title: const Text('Add Expense'), backgroundColor: const Color(0xFF0A3D62)),
      body: Padding(padding: const EdgeInsets.all(12.0), child: Column(children: [
        TextField(controller: _title, decoration: const InputDecoration(labelText: 'Title')),
        const SizedBox(height:8),
        TextField(controller: _amount, decoration: const InputDecoration(labelText: 'Amount'), keyboardType: TextInputType.number),
        const SizedBox(height:12),
        ElevatedButton(onPressed: _save, child: const Text('Save Expense'), style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF145A8D)))
      ])));
  }
  void _save() {
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Expense saved (placeholder)')));
  }
}
