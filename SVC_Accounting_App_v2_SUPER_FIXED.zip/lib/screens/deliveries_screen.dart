import 'package:flutter/material.dart';
class DeliveriesScreen extends StatefulWidget { const DeliveriesScreen({super.key}); @override State<DeliveriesScreen> createState() => _DeliveriesScreenState(); }
class _DeliveriesScreenState extends State<DeliveriesScreen> {
  final _customer = TextEditingController();
  final _details = TextEditingController();
  final _total = TextEditingController();
  @override Widget build(BuildContext context) {
    return Scaffold(appBar: AppBar(title: const Text('Deliveries'), backgroundColor: const Color(0xFF0A3D62)),
      body: Padding(padding: const EdgeInsets.all(12.0), child: Column(children: [
        TextField(controller: _customer, decoration: const InputDecoration(labelText: 'Customer Name')),
        const SizedBox(height:8),
        TextField(controller: _details, decoration: const InputDecoration(labelText: 'Details')),
        const SizedBox(height:8),
        TextField(controller: _total, decoration: const InputDecoration(labelText: 'Total'), keyboardType: TextInputType.number),
        const SizedBox(height:12),
        ElevatedButton(onPressed: _save, child: const Text('Save Delivery'), style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF145A8D)))
      ])));
  }
  void _save() {
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Delivery saved (placeholder)')));
  }
}
