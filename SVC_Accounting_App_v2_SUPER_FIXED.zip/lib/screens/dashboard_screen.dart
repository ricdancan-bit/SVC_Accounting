import 'package:flutter/material.dart';
import 'sales_screen.dart';
import 'expenses_screen.dart';
import 'deliveries_screen.dart';

class DashboardScreen extends StatelessWidget {
  const DashboardScreen({super.key});
  @override Widget build(BuildContext context) {
    return Scaffold(appBar: AppBar(title: const Text('SALIM VENTURE COMPANY'), centerTitle: true, backgroundColor: const Color(0xFF0A3D62)),
      body: Padding(padding: const EdgeInsets.all(16.0), child: Column(children: [
        Card(color: const Color(0xFFD4E6F1), child: Padding(padding: const EdgeInsets.all(12.0), child: Row(mainAxisAlignment: MainAxisAlignment.spaceAround, children: [
          Column(children: const [Text('Total Sales'), SizedBox(height:8), Text('0')]),
          Column(children: const [Text('Total Expenses'), SizedBox(height:8), Text('0')]),
          Column(children: const [Text('Balance'), SizedBox(height:8), Text('0')])
        ]))),
        const SizedBox(height:12),
        Wrap(spacing:12, children: [
          ElevatedButton(onPressed: () { Navigator.push(context, MaterialPageRoute(builder: (_) => const SalesScreen())); }, child: const Text('Add Sale'), style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF145A8D))),
          ElevatedButton(onPressed: () { Navigator.push(context, MaterialPageRoute(builder: (_) => const ExpensesScreen())); }, child: const Text('Add Expense'), style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF145A8D))),
          ElevatedButton(onPressed: () { Navigator.push(context, MaterialPageRoute(builder: (_) => const DeliveriesScreen())); }, child: const Text('Deliveries'), style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF145A8D)))
        ])
      ])));
  }
}
