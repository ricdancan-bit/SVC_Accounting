final Map<String, int> productPrices = {
  'Short Feeder': 70,
  'Long Feeder': 120,
  '1 Litre Drinker': 80,
  '1.5 Litres Drinker': 120,
  '1.5 Kgs Feeder': 120,
  '3 Litres Drinker': 150,
  '3 Kgs Feeder': 180,
  '6 Litres Drinker': 250,
  '6 Kgs Feeder': 300,
  '9 Kgs Feeder': 400,
  '11 Litres Drinker': 350,
};
