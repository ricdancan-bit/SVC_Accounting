import 'package:firebase_core/firebase_core.dart';
class DefaultFirebaseOptions {
  static FirebaseOptions get currentPlatform {
    return const FirebaseOptions(
      apiKey: 'REPLACE_WITH_API_KEY',
      appId: 'REPLACE_WITH_APP_ID',
      messagingSenderId: 'REPLACE_WITH_SENDER_ID',
      projectId: 'salim-venture-company',
      storageBucket: 'salim-venture-company.firebasestorage.app',
    );
  }
}
